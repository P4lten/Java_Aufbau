package animals.funcInterfaces;

public class LambdaExpressionsDemo {

	public static void main(String[] args) {
		AnimalList animals = new AnimalList();
		animals.showAll();

		// statt anonymer Klasse
//		AnimalFilter filter1 = new AnimalFilter() {
//			// Implementierung für die isTrueFor-Methode
//			@Override
//			public boolean isTrueFor(Animal a) {
//				return a.isHerbivore();
//			}
//		
//		}; // Strichpunkt schließt Deklaration ab

		AnimalFilter filter1 = (a) -> {
			// Implementierung der Methode isTrueFor ohne Methoden-Gerüst
			return a.isHerbivore();
		};// Strichpunkt schließt Deklaration ab
		System.out.println("Pflanzenfresser:");
		System.out.println("Filterobjekt: " + filter1.getClass().getName());
		animals.showAnimals(filter1);

		// Lambda Expression ohne Hilfsvariable
		System.out.println("Fleischfresser:");
		// Klammern um Argumente und Blockklammern dürfen hier weggelassen werden
		animals.showAnimals(a -> !a.isHerbivore());

		// Tiere sortieren mit Comparator
		// statt anonymer Klasse
//		animals.sortiere(new Comparator<Animal>() {
//
//			@Override
//			public int compare(Animal o1, Animal o2) {
//
//				return o2.getWeight() - o1.getWeight();
//			}
//		});
		
		// Lambda Expression
		animals.sortiere((a1, a2) -> a2.getWeight() - a1.getWeight());
		System.out.println("Tiere sortiert:");
		animals.showAll();
		
		// nach Pflanzenfresser und Gewicht sortiert
		animals.sortiere((a1, a2) -> {
			int ret = Boolean.compare(a1.isHerbivore(), a2.isHerbivore());
			// wenn gleich -> nach Gewicht aufsteigend 
			if(ret== 0) {
				ret = Integer.compare(a1.getWeight(), a2.getWeight());
			}
			return ret;
		});
		System.out.println("Nach Pflanzenfresser und Gewicht sortiert:");
		animals.showAll();

	}

}
