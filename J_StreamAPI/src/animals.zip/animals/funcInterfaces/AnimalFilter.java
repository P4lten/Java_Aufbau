package animals.funcInterfaces;

// Dieses Interface verwenden wir für die Tier-Filterung.
// Implementierende Klassen können in ihrer isTrueFor-Implementierung
// festlegen, ob das übergebene Animal-Objekt im Ergebnis enthalten
// sein soll oder nicht
@FunctionalInterface
public interface AnimalFilter {
	boolean isTrueFor(Animal a);

	// darf keine weiteren abstrakten Methoden enthalten
}
