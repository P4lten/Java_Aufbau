package animals.funcInterfaces;






public class HerbivoreFilter implements AnimalFilter{

	@Override
	public boolean isTrueFor(Animal a) {
		return a.isHerbivore();
	}

}
