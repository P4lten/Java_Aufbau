﻿package xml.model;


import java.util.ArrayList;
import java.util.List;


public class Fahrzeuge {

	private final List<Fahrzeug> fahrzeuge = new ArrayList<>();

	public List<Fahrzeug> getFahrzeuge() {
		return fahrzeuge;
	}

}
