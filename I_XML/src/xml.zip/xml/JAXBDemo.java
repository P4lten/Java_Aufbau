﻿package xml;

import java.time.LocalDate;
import java.util.Scanner;

import xml.model.Auto;
import xml.model.Fahrrad;
import xml.model.Fahrzeuge;
import xml.model.LKW;

public class JAXBDemo {
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.print("Daten speichern? j/n");
		boolean saveData = scanner.nextLine().charAt(0) == 'j';
		boolean readData = saveData ? saveData("fahrzeuge.xml") : true;

		if (saveData) {
			System.out.println("Weiter mit Return");
			scanner.nextLine();
		}
		if (readData)
			readData("fahrzeuge.xml");
	}

	private static boolean saveData(String fileName) {

		Fahrzeuge fz = new Fahrzeuge();
		fz.getFahrzeuge().add(new Auto("Mercedes", 30000, LocalDate.of(2019, 12, 15), 110, "Silber"));
		fz.getFahrzeuge().add(new LKW("MAN", 150000, LocalDate.of(2020, 10, 2), 320, "Rot", 8000, 100, 3));
		fz.getFahrzeuge().add(new Fahrrad("KTM", 2000, LocalDate.of(2020, 5, 21), 27, "Mountainbike"));

		System.out.println("Folgende Fahrzeuge werden gespeichert");
		for (int i = 0; i < fz.getFahrzeuge().size(); ++i) {
			System.out.println(fz.getFahrzeuge().get(i));
		}

		// TODO: Daten speichern
		try {

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	private static boolean readData(String fileName) {
		// TODO: Daten laden
		try {

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}
}
